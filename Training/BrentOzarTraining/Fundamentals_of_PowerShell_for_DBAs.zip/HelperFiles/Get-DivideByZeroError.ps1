[cmdletbinding()] 
param ()

process {
    $div = 1 / 0
    $div
}