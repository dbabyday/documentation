/*
Fundamentals of Columnstore: Partitioning Is a Great Partner for Columnstore
Part 1: Building the Partitioned Columnstore Table

v1.1 - 2022-07-09
https://www.BrentOzar.com/go/columnfund


This demo requires:
* SQL Server 2016 SP1 or newer
* Stack Overflow database 2018-06 version: https://www.BrentOzar.com/go/querystack

*/
USE StackOverflow;
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 130;
GO
CREATE PARTITION FUNCTION VotesPartitionFunction (datetime)
	AS RANGE RIGHT FOR VALUES
	('2017-01-01', '2018-01-01', '2019-01-01',
	 '2020-01-01', '2021-01-01', '2022-01-01',
	 '2023-01-01', '2024-01-01', '2025-01-01');

/* Create matching partition scheme, but put everything in Primary: */
CREATE PARTITION SCHEME VotesPartitionScheme  
AS PARTITION VotesPartitionFunction  
ALL TO ( [PRIMARY] ); 
GO


DROP TABLE IF EXISTS [dbo].[Votes_columnstore_partitioned];
GO
CREATE TABLE [dbo].[Votes_columnstore_partitioned](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PostId] [int] NOT NULL,
	[UserId] [int] NULL,
	[BountyAmount] [int] NULL,
	[VoteTypeId] [int] NOT NULL,
	[CreationDate] [datetime] NOT NULL
)
GO
/* For staging purposes, cluster on PostId.
This isn't a columnstore index, but I'm naming
it CCI because I'm going to replace it shortly. */
CREATE CLUSTERED INDEX CCI ON 
	dbo.Votes_columnstore_partitioned (PostId)
	ON VotesPartitionScheme(CreationDate);
GO
SET IDENTITY_INSERT dbo.[Votes_columnstore_partitioned] ON;
GO
INSERT INTO dbo.[Votes_columnstore_partitioned] 
	(Id, PostId, UserId, BountyAmount, VoteTypeId, CreationDate)
	SELECT Id, PostId, UserId, BountyAmount, VoteTypeId, CreationDate
	FROM dbo.Votes;
GO
SET IDENTITY_INSERT dbo.[Votes_columnstore_partitioned] OFF;
GO
/* Switch to a clustered columnstore index. */
CREATE CLUSTERED COLUMNSTORE INDEX CCI
	ON dbo.Votes_columnstore_partitioned
	WITH (DROP_EXISTING = ON, MAXDOP = 1)
GO



/*
License: Creative Commons Attribution-ShareAlike 4.0 Unported (CC BY-SA 4.0)
More info: https://creativecommons.org/licenses/by-sa/4.0/

You are free to:
* Share - copy and redistribute the material in any medium or format
* Adapt - remix, transform, and build upon the material for any purpose, even 
  commercially

Under the following terms:
* Attribution - You must give appropriate credit, provide a link to the license, 
  and indicate if changes were made. You may do so in any reasonable manner, 
  but not in any way that suggests the licensor endorses you or your use.
* ShareAlike - If you remix, transform, or build upon the material, you must
  distribute your contributions under the same license as the original.
* No additional restrictions — You may not apply legal terms or technological 
  measures that legally restrict others from doing anything the license permits.
*/